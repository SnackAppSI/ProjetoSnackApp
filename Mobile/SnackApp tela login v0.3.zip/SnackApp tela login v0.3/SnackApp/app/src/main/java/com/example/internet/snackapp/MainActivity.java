package com.example.internet.snackapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    EditText txtlogin;
    EditText txtsenha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();


        txtlogin = (EditText) findViewById(R.id.txtLogin);
        txtsenha = (EditText) findViewById(R.id.txtSenha);

    }



    public void verLogin (View view)
    {

        String login = null, senha = null;

        if (txtlogin.getText().toString().equals(""))
        {
            login="Vazio";
        }
        else
            login = (txtlogin.getText().toString());

        if (txtsenha.getText().toString().equals(""))
        {
            senha="Vazio";
        }
        else
            senha = (txtsenha.getText().toString());


        if (login.equals("brunohcsv") && senha.equals("batata"))
        {
            Toast.makeText(this, "BELEZA", Toast.LENGTH_LONG).show();
        }
        else
            Toast.makeText(this, "USUÁRIO INVÁLIDO", Toast.LENGTH_LONG).show();


    }
}
